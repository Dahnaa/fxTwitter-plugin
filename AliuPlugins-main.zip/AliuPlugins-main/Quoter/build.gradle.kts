version = "1.2.2"
description = "Re-adds the famous quote button in the message context menu."