version = "1.4.0"
description = "(tries to) Add icons for connections unsupported by Discord Kotlin"
