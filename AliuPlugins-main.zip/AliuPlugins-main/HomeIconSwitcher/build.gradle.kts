version = "1.0.3"
description = "switch the home icon above guild list also fresco sucks"