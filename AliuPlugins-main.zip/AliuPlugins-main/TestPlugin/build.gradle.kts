version = "1.0.0"
description = "test plugin"

aliucord {
    excludeFromUpdaterJson.set(true)
}