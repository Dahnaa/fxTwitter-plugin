version = "1.0.4"
description = "View comic-like drawings from xkcd.com"