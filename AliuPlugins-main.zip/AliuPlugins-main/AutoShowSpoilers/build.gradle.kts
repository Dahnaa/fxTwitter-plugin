version = "1.1.0"
description = "Automatically clicks on spoilers for you"