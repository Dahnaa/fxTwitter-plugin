version = "1.0.4"
description = "Sends you in-app notifications when someone reacts to your message"