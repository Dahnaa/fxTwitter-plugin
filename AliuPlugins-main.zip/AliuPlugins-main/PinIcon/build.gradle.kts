version = "1.1.0"
description = "Shows a pin icon next to messages that have been pinned"

aliucord {
    author("Tyman", 487443883127472129L) // helped with weird crashing and stuff
}