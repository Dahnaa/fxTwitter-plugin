version = "1.0.3"
description = "Go to a certain channel on app startup"