version = "1.0.3"
description = "Lets you lock channels so you cant type in them anymore"