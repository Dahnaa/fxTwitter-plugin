version = "69.420.0.0"
description = "This will crash your discord, you fucking idiot."