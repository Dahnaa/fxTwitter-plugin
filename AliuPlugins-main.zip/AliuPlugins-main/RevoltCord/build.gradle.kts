version = "1.1.2"
description = "WebViewCord but for Revolt"