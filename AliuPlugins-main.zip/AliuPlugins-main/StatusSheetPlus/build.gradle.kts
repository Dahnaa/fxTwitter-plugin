version = "1.0.0"
description = "A better and more compact status picker"